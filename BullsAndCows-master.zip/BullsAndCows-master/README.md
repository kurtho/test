# BullsAndCows

This is a prototype of the [bulls and cows](https://en.wikipedia.org/wiki/Bulls_and_Cows) game.

There are 6 **TODO**s in the project, please complete these TODOs.
